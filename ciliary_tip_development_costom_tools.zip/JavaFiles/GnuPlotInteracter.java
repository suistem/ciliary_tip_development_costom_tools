package ciliaCalculations;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.ProcessBuilder.Redirect;
import java.util.ArrayList;

public class GnuPlotInteracter {
   static String dir;// = "C:/Users/Owner/Documents/College/Lab/Matt_R_Summer_2016/WidthProfileData/summer2017/3hrs";
   static String time;// = dir;
   static String gnuPlotDirectory = "C:/Program Files (x86)/gnuplot/bin/";
   
   public static void main(String args[]) throws IOException {
      if (args.length != 1) {
         System.out.println("Please input exactly one directory");
      } else {
         dir = args[0];
         time = dir;
         System.setProperty("user.dir", dir);
         
         File folder = new File(time);
         File[] listOfFiles = folder.listFiles();
         
         for (File f : listOfFiles) {
            processBuilder(f.getAbsolutePath().substring(0,f.getAbsolutePath().lastIndexOf('.')));
         }
      }
   }
   
   public static void processBuilder(String fileName) throws IOException {
      ArrayList<String> str = new ArrayList<String>();
      str.add(gnuPlotDirectory + "gnuplot");
      
      File pltFile = new File(fileName + ".plt");
      try {
         PrintWriter writer = new PrintWriter(pltFile);
         writer.println("set terminal pdf");
         String setPictureFileName = "set output '" + fileName + ".pdf'";
         writer.println(setPictureFileName);
         writer.println("cd " + "\"" + dir + "\"");
         writer.println(
               "set title 'Cilium width profile for cilium " + fileName.substring(fileName.lastIndexOf('\\')) + "'");
         writer.println(
               "set xlabel 'Distance from cilium tip along central axis (nm)'");
         writer.println("set ylabel 'Cilium width (nm)'");
         writer.println("unset key");
         writer.println("set key autotitle columnhead");
         writer.println("set datafile separator ','");
         writer.println("set datafile missing '0'");
         writer.println("set style line 1 lc rgb 'black' pt 7 ps 0.5");
         writer.println("set tics nomirror");
         writer.println("set border 3");
         writer.println("set xrange [0:3500]");
         writer.println("set yrange [0:400]");
         writer.println(
               "f(x) = a1*x**6 + a*x**5 + b*x**4 + c*x**3 + d*x**2 + e*x + f; a=0.00000001; a1=0.000000000001; b=0.000001; c=0.00001; d=0.0001; e=0.01; f=100");
         writer.println("fit f(x) '" + fileName + ".csv' using 1:2 via a1,a,b,c,d,e,f");
         writer.println("plot '" + fileName+".csv' using 1:2 w p ls 1, f(x)");
         writer.println("set print \"coefficients.txt\" append");
         writer.println("print a1,a,b,c,d,e,f");
         writer.close();
      } catch (IOException e) {
         System.out.println(e);
      }
      
      str.add(pltFile.getAbsolutePath());
      ProcessBuilder pb = new ProcessBuilder(str);
      pb.directory(new File(gnuPlotDirectory));
      File log = new File(dir + "log.txt");
      pb.redirectErrorStream(true);
      pb.redirectOutput(Redirect.appendTo(log));
      System.out.println(pb.command());
      Process p = pb.start();
      assert pb.redirectInput() == Redirect.PIPE;
      assert pb.redirectOutput().file() == log;
      assert p.getInputStream().read() == -1;
   }
}