package ciliaCalculations;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DerivativeCalculator {
   public static double[] finalVals;
   public static String filePath;
   public static void main(String[] args) {
      if(args.length != 1){
         System.out.println("Please input exactly one file");
      } else {
         filePath = args[0];
         System.out.println(filePath);
         ArrayList<double[]> coefficients = parseCoeffFile();
         for (int i = 0; i < coefficients.size(); i++) {
            finalVals = calculateDiscreteDerivative(coefficients.get(i));
            System.out.println(tipLength().toString());
         }
      }
   }
   
   private static double[] calculateDiscreteDerivative(double... coeffs) {
      // Calculate First Derivative
       return fxnCalculator(derivCoeffFinder(coeffs), coeffs);
   }
   
   private static double[] derivCoeffFinder(double[] coeffs) {
      int fxnOrder = coeffs.length - 1;
      double[] derivCoeffs = new double[fxnOrder];
      
      for (int i = fxnOrder, j = 0; i > 0; i--, j++) {
         derivCoeffs[j] = i * coeffs[j];
      }
      return derivCoeffs;
   }
   
   private static double[] fxnCalculator(double[] derivCoeffs, double[] coeffs) {
      int deriveOrder = derivCoeffs.length - 1;
      int xresolution = 3500;
      double[] values = new double[xresolution];
      for (int i = 0; i < xresolution; i = i + 1) {
         double temp = 0.0;
         for (int j = 0; j < deriveOrder + 1; j++) {
            temp = temp + derivCoeffs[j] * Math.pow(i, deriveOrder - j);
         }
         values[i] = temp;
      }
      return values;
   }
   
   private static ArrayList<Integer> tipLength(){
      ArrayList<Integer> posOfZeroes = new ArrayList<Integer>();
      for(int i = 1; i<finalVals.length-1; i++){
         if((finalVals[i-1] > 0.0524 && finalVals[i+1]<0.0524)){//TODO
            posOfZeroes.add(i);
         }
      }
      return posOfZeroes;
   }
   
   private static ArrayList<double[]> parseCoeffFile() {
      ArrayList<double[]> coeffs = new ArrayList<double[]>();
      try {
         BufferedReader buff = new BufferedReader(new FileReader(filePath));
               // "C:/Users/Owner/Documents/College/Lab/Matt_R_Summer_2016/WidthProfileData/TetrahymenaRawCSV/GraphCoeffs/coefficients-8h.txt"));
         while (buff.ready()) {
            String[] temp = buff.readLine().split(" ");
            double[] temp1 = new double[temp.length];
            for (int i = 0; i < temp.length; i++) {
               temp1[i] = Double.parseDouble(temp[i]);
            }
            coeffs.add(temp1);
         }
         buff.close();
      } catch (FileNotFoundException e) {
         e.printStackTrace();
      } catch (IOException e) {
         e.printStackTrace();
      }
      
      return coeffs;
      
   }
}
