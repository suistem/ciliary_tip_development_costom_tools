package Cilia;
import java.awt.Polygon;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

import ij.IJ;
import ij.gui.PolygonRoi;
import ij.ImagePlus;
//import ij.WindowManager;
import ij.gui.GenericDialog;
import ij.gui.Line;
import ij.gui.Plot;
import ij.gui.PlotWindow;
import ij.gui.Roi;
import ij.measure.ResultsTable;
import ij.plugin.PlugIn;
import ij.plugin.filter.Analyzer;
import ij.process.ImageProcessor;

/**
 * This class produces a width profile of a cilium or flagellum. The program works on straight and
 * segmented lines that are drawn through the axes of the cilium/flagellum of interest. Basically,
 * after traversing one pixel's distance along the axis, a perpendicular line is extended. From this
 * perpendicular line, the edges of the cilium are automatically detected and the width is recorded.
 * @author Matthew Reynolds
 */
public class FlagellaWidthProfile_ implements PlugIn {
   private final static int PERP_LINE_LENGTH = 600; // length of the line extended perpendicularly to the
                                             // cilium's axis, in pixels
   private static int MAX_PIXEL_VALUE = 32767; // maximum pixel value after performing a bandpass
                                              // filter
   ImagePlus imp; 
   ArrayList<Coordinate> coords = new ArrayList<Coordinate>(PERP_LINE_LENGTH * 3);
   static ArrayList<Double> widths = new ArrayList<Double>(PERP_LINE_LENGTH * 3);
   ArrayList<ArrayList<Coordinate>> perpLines = new ArrayList<ArrayList<Coordinate>>();
   static double[] xValues;
   static double[] yValues;
   static double[] medianXValues;
   static double[] medianYValues;
   static File imageFile;
   
   // These parameters are specified by the user on plugin startup //
   // magnification of EM used has options of "8KX", "10KX", "5KX", and "Pixels"
   static double multiplier = 0; 
   // establish a cutoff for which fitness values are good enough to be considered edges
   static double fitnessCutoff = 0;
   static double displacementWeight = 50;
   static double brightnessWeight = 50;
   
   /**
    * This is the program's main method in that it runs when the plugin is called. This method
    * primarily calls other methods to act on the region of interest specified in the current
    * ImagePlus. Any unreasonable widths that are calculated will be rejected.
    */
   @Override
   public void run(String arg) {
    //  imp = WindowManager.getCurrentImage();
      imageFile = new File(IJ.getFilePath("Please select the file to run the program on"));
      imp = IJ.openImage(imageFile.getAbsolutePath());//IJ.getFilePath("Please select the file to run the program on"));
      
      if (imp == null) { // an image must be open to run this plugin
         IJ.noImage();
         return;
      }
      determineMultiplier();
      if(multiplier == 0){
         return;
      }
      Roi roi = imp.getRoi();
      
      if (roi == null) { // there must be an active ROI for the algorithm
         IJ.error("Flagella Width Profile", "Selection required");
         return;
      }
      int roiType = roi.getType();
      if (!roi.isLine() || roiType == Roi.FREELINE) {
         IJ.error("Straight or segmented line selection required.");
         return;
      }
      
      if (roiType == Roi.LINE) {
         handleLine(roi);
      } else if (roiType == Roi.POLYLINE) {
         handlePolyline(roi);
         
      }
      medianCalculator();
    //  ResultsTable();
      printCSV();
      Plot plot = new Plot("Flagella Width Profile",
            "Distance from Flagellar Tip (nm)", "Flagella Width (nm)");
      plot.add("X", medianXValues, medianYValues);
      plot.draw(); // provides a preview graph of the width profile
      plot.setFrameSize(1200, 200);
      PlotWindow window = plot.show();
      window.setLocationAndSize(0, 800, 1200, 200);
       
      
      widths.clear();
   }
   
   /**
    * The determineMultiplier method allows the user to interface with the plugin by
    * specifying the magnification of the image. The built-in comparisons allow for
    * reported widths to have units in nanometers instead of pixels.
    */
   private static void determineMultiplier(){
      GenericDialog dialogBox = new GenericDialog("Parameters");
      String[] items = {"8KX", "5KX", "10KX", "Pixels"};
      dialogBox.addChoice("Magnification", items, items[0]);
      dialogBox.addSlider("Fitness Cutoff", 0, 3, 2.2);
      dialogBox.addSlider("Brightness Weights", 0, 100, 50);
      dialogBox.addSlider("Displacement Weight", 0, 100, 50);
      String[] bit = {"8bit", "16bit"};
      dialogBox.addChoice("Bit", bit, bit[0]);
      
      dialogBox.showDialog();
      if (dialogBox.wasCanceled()){
         return;
      }
      String magnification = dialogBox.getNextChoice();
      if(magnification.equals("5KX")){
         multiplier = 2.3;
      }else if(magnification.equals("8KX")){
         multiplier = 1.5;
      }else if(magnification.equals("10KX")){
         multiplier = 1.2;
      }else if(magnification.equals("Pixels")){
         multiplier = 1.0;
      }
      fitnessCutoff = dialogBox.getNextNumber();
      brightnessWeight = dialogBox.getNextNumber();
      displacementWeight =dialogBox.getNextNumber();
      String bitNum = dialogBox.getNextChoice();
      if(bitNum.equals("8bit")){
         MAX_PIXEL_VALUE = 255;
      }else if(bitNum.equals("16bit")){
         multiplier = 32767;
      }
   }
   
   /**
    * This method transforms the data in the widths ArrayList into an easy-to
    * visualize form by copying the values into two parallel arrays. The first step
    * is to remove all values where the width was determined to be zero. These cases
    * are considered failures in the optimization and are rejected. Then, the median
    * of every three points is taken and copied into the new arrays. These new median
    * arrays contain the data to be graphed.
    */
   private static void medianCalculator(){
      int cntr = 0;
      for(int i = 0; i<widths.size(); i++){
         if(widths.get(i) != 0.0){
            cntr++;
         }
      }
      xValues = new double[cntr];
      yValues = new double[cntr];
      cntr = 0;
      for(int i = 0; i<xValues.length; i++){
         if(widths.get(i) != 0.0){
            xValues[cntr] = i * multiplier;
            yValues[cntr] = widths.get(i) * multiplier;
            cntr++;
         }
      }
      medianXValues = new double[xValues.length / 3];
      medianYValues = new double[yValues.length / 3];
      cntr = 0;
      for (int i = 1; i < xValues.length-1; i = i + 3) {
         if (yValues[i - 1] >= yValues[i]) {
            if (yValues[i] >= yValues[i + 1]) {
               medianXValues[cntr] = xValues[i];
               medianYValues[cntr] = yValues[i];
            } else if (yValues[i - 1] >= yValues[i + 1]) {
               medianXValues[cntr] = xValues[i + 1];
               medianYValues[cntr] = yValues[i + 1];
            } else {
               medianXValues[cntr] = xValues[i - 1];
               medianYValues[cntr] = yValues[i - 1];
            }
         } else {
            if (yValues[i - 1] >= yValues[i + 1]) {
               medianXValues[cntr] = xValues[i - 1];
               medianYValues[cntr] = yValues[i - 1];
            } else if (yValues[i] >= yValues[i + 1]) {
               medianXValues[cntr] = xValues[i + 1];
               medianYValues[cntr] = yValues[i + 1];
            } else {
               medianXValues[cntr] = xValues[i];
               medianYValues[cntr] = yValues[i];
            }
         }
         cntr++;
      }
   }
   
   /**
    * This method prints the results of the width profile into a CSV
    * file in the same directory
    */
   private static void printCSV(){
      //System.out.println(imageFile.getAbsolutePath() + "_widthProfile.csv");
      PrintWriter pw = null;
      try {
         pw = new PrintWriter(new File(imageFile.getAbsolutePath() + "_widthProfile.csv"));
      } catch (FileNotFoundException e) {
         e.printStackTrace();
      }
      StringBuilder builder = new StringBuilder();
      String ColumnNamesList = "Position along Cilium,Width";
      builder.append(ColumnNamesList + "\n");
      for (int i = 0; i < medianXValues.length; i++) {
         builder.append(medianXValues[i] + "," + medianYValues[i]);
         builder.append("\n");
      }
      
      pw.write(builder.toString());
      pw.close();
   }
   
   /**
    * This method updates a results table with all of the gathered data. Widths are only reported if
    * they are not equal to zero.
    */
   @SuppressWarnings("unused")
   private static void ResultsTable() {
      ResultsTable rt = Analyzer.getResultsTable();
      if (rt == null) {
         rt = new ResultsTable();
         Analyzer.setResultsTable(rt);
      }
      for (int i = 0; i < medianXValues.length; i++) {
            rt.incrementCounter();
            rt.addValue("Position along Cilia", medianXValues[i]);
            rt.addValue("Width", medianYValues[i]);
      }
      rt.show("Results");
      ij.measure.ResultsTable.getResultsWindow().setLocation(1400, 780);
   }
   
   /**
    * This method extends many lines perpendicular to the line defined by the passed Roi, and it
    * calls methods to first draw these lines and then detect the edges of the cilium that
    * intersects the lines. Once all actions are performed, the ArrayLists are cleared.
    * 
    * @param roi
    *           the roi in this case is a segmented line
    */
   private void handleLine(Roi roi) {
      Polygon p = ((Line) roi).getPoints();
      coords = coordinatesAndSlope(p.xpoints[0], p.ypoints[0], p.xpoints[1], p.ypoints[1]);
      
      for (int i = 0; i < coords.size(); i++) {
         double posX = (coords.get(i).getXValue() + (PERP_LINE_LENGTH / 2));
         double posY = (-1.0 / coords.get(i).getSlope()) * (PERP_LINE_LENGTH / 2) + coords.get(i).getYValue();
         double negX = (coords.get(i).getXValue() - (PERP_LINE_LENGTH / 2));
         double negY = ((PERP_LINE_LENGTH / 2) / coords.get(i).getSlope()) + coords.get(i).getYValue();
         
         perpLines.add(coordinatesAndSlope(negX, negY, posX, posY));
         widths.add(i, widthDetermination(perpLines.get(i)));
      }
      coords.clear();
      perpLines.clear();
   }
   
   /**
    * This method handles the case of a segmented line being drawn by dividing the segmented line
    * into a series of straight lines and passing each straight line to the handleLine method.
    * 
    * @param roi
    *           the roi in this case is a segmented line or polyline
    */
   private void handlePolyline(Roi roi) {
      Polygon p = ((PolygonRoi) roi).getPolygon();
      for (int i = p.npoints - 1; i > 0; i--) {
         Line tempLine = new Line(p.xpoints[i - 1], p.ypoints[i - 1], p.xpoints[i], p.ypoints[i]);
         handleLine(tempLine);
      }
   }
   
   /**
    * This method returns an ArrayList containing all of the Coordinates contained on a line between
    * two points.
    * 
    * @param x1
    *           the x value of the first point passed to the method
    * @param y1
    *           the y value of the first point passed to the method
    * @param x2
    *           the x value of the second point passed to the method
    * @param y2
    *           the y value of the second point passed to the method
    * @return returns an ArrayList of Coordinates that lie along the line defined by the two points
    *         passed to the method
    */
   public ArrayList<Coordinate> coordinatesAndSlope(double x1, double y1, double x2, double y2) {
      ImageProcessor ip = imp.getProcessor();
      int height = ip.getHeight();
      int width = ip.getWidth();
      double dx = x2 - x1;
      double dy = y2 - y1;
      double slope = dy / dx;
      int n = (int) Math.round(Math.sqrt(dx * dx + dy * dy));
      double xinc = dx / n;
      double yinc = dy / n;
      if (!((xinc == 0 && n == height) || (yinc == 0 && n == width)))
         n++;
      ArrayList<Coordinate> data = new ArrayList<Coordinate>();
      double rx = x1;
      double ry = y1;
      for (int i = 0; i < n; i++) {
         Coordinate temp = new Coordinate();
         temp.setXValue(rx);
         temp.setYValue(ry);
         temp.setSlope(slope);
         temp.setPixelValue(ip);
         data.add(temp);
         rx += xinc;
         ry += yinc;
      }
      return data;
   }
   
   /**
    * This method determines the width of the cilium at all points.
    * 
    * @param perpLineGrays
    * @return the width of the cilium for all Coordinates
    */
   public double widthDetermination(ArrayList<Coordinate> perpLineGrays) {
      
      ArrayList<Coordinate> potentialRightPeaks = new ArrayList<Coordinate>();
      ArrayList<Coordinate> potentialLeftPeaks = new ArrayList<Coordinate>();
      Coordinate center = perpLineGrays.get(perpLineGrays.size() / 2);
      
      for (int i = (perpLineGrays.size() / 2); i < perpLineGrays.size() - 4; i++) {
         // finds local maxima
         if (perpLineGrays.get(i - 4).getPixelValue() <= perpLineGrays.get(i - 3).getPixelValue()
               && perpLineGrays.get(i - 3).getPixelValue() <= perpLineGrays.get(i - 2).getPixelValue()
               && perpLineGrays.get(i - 2).getPixelValue() <= perpLineGrays.get(i - 1).getPixelValue()
               && perpLineGrays.get(i - 1).getPixelValue() <= perpLineGrays.get(i).getPixelValue()
               && perpLineGrays.get(i).getPixelValue() >= perpLineGrays.get(i + 1).getPixelValue()
               && perpLineGrays.get(i + 1).getPixelValue() >= perpLineGrays.get(i + 2).getPixelValue()
               && perpLineGrays.get(i + 2).getPixelValue() >= perpLineGrays.get(i + 3).getPixelValue()
               && perpLineGrays.get(i + 3).getPixelValue() >= perpLineGrays.get(i + 4).getPixelValue()
               && perpLineGrays.get(i).getPixelValue() !=0) {
            potentialRightPeaks.add(perpLineGrays.get(i));
         }
      }
      for (int i = (perpLineGrays.size() / 2) - 1; i > 4; i--) {
         if (perpLineGrays.get(i - 4).getPixelValue() <= perpLineGrays.get(i - 3).getPixelValue()
               && perpLineGrays.get(i - 3).getPixelValue() <= perpLineGrays.get(i - 2).getPixelValue()
               && perpLineGrays.get(i - 2).getPixelValue() <= perpLineGrays.get(i - 1).getPixelValue()
               && perpLineGrays.get(i - 1).getPixelValue() <= perpLineGrays.get(i).getPixelValue()
               && perpLineGrays.get(i).getPixelValue() >= perpLineGrays.get(i + 1).getPixelValue()
               && perpLineGrays.get(i + 1).getPixelValue() >= perpLineGrays.get(i + 2).getPixelValue()
               && perpLineGrays.get(i + 2).getPixelValue() >= perpLineGrays.get(i + 3).getPixelValue()
               && perpLineGrays.get(i + 3).getPixelValue() >= perpLineGrays.get(i + 4).getPixelValue()
               && perpLineGrays.get(i).getPixelValue() != 0) {
            potentialLeftPeaks.add(perpLineGrays.get(i));
         }
      }
      // i.e. if there are no potential peaks on either the left or right side
      if (potentialLeftPeaks.isEmpty() || potentialRightPeaks.isEmpty()) {
         return 0.0;
      } else {
         Coordinate tempLeftPeak = potentialLeftPeaks.get(0);
         Coordinate tempRightPeak = potentialRightPeaks.get(0);
         double topPeak = peakFitness(tempLeftPeak, tempRightPeak, center);
         double potentialTopPeak;
         for (int i = 0; i < potentialLeftPeaks.size(); i++) {
            for (int j = 0; j < potentialRightPeaks.size(); j++) {
               potentialTopPeak = peakFitness(potentialLeftPeaks.get(i), potentialRightPeaks.get(j), center);
               if (potentialTopPeak > topPeak) {
                  tempLeftPeak = potentialLeftPeaks.get(i);
                  tempRightPeak = potentialRightPeaks.get(j);
                  topPeak = potentialTopPeak;
               }
            }
         }
         if(topPeak < fitnessCutoff){
            return 0.0;
         }
         return distanceBtwnCoordinates(tempLeftPeak, tempRightPeak);
      }     
   }
   
   /**
    * This method is the fitness function for the width determination
    * optimization algorithm. Using the parameters for brightness and
    * displacement provided by the user, each peak is pairing is evaluated
    * for its fitness. If the displacement is too high between peaks, then
    * the pairing is rejected by being assigned a negative weight.
    * 
    * @param leftPeak
    * @param rightPeak
    * @param center
    * @return
    */
   public static double peakFitness(Coordinate leftPeak, Coordinate rightPeak,
         Coordinate center) {
      double leftHeightFitness = (brightnessWeight/100) * (double)leftPeak.getPixelValue() / (double)MAX_PIXEL_VALUE;
      double rightHeightFitness = (brightnessWeight/100) * (double)rightPeak.getPixelValue() / (double)MAX_PIXEL_VALUE;
      double leftDisplacement = distanceBtwnCoordinates(leftPeak, center);
      double rightDisplacement = distanceBtwnCoordinates(rightPeak, center);
      double disp;
      if (leftDisplacement < rightDisplacement) {
         disp = (4*displacementWeight/100)*leftDisplacement / distanceBtwnCoordinates(leftPeak, rightPeak);
      } else {
         disp = (4*displacementWeight/100)*rightDisplacement / distanceBtwnCoordinates(leftPeak, rightPeak);
      }
      double tooLong = 0;
      if(distanceBtwnCoordinates(leftPeak, rightPeak) > PERP_LINE_LENGTH/2){ tooLong = -400;}
      double fitness =leftHeightFitness + rightHeightFitness + disp + tooLong;
      //System.out.println(leftHeightFitness + " " + rightHeightFitness  + " " + disp);
      return fitness;
   }
   
   /**
    * This method calculates the distance, in pixels, between two Coordinate objects, representing
    * two points on an image. The calculation is done simply using the two-dimensional distance
    * formula, and the result is returned as a double.
    * 
    * @param coord1
    *           the first Coordinate object passed as a parameter. This serves as one of the points.
    * @param coord2
    *           the second Coordinate object passed as a parameter. This serves as the second point.
    * @return the distance between the two coordinates
    */
   public static double distanceBtwnCoordinates(Coordinate coord1, Coordinate coord2) {
      double dx = coord1.getXValue() - coord2.getXValue(); // difference in x values
      double dy = coord1.getYValue() - coord2.getYValue(); // difference in y values
      return Math.sqrt(dx * dx + dy * dy); // two-dimensional distance formula
   }
   
   /**
    * The nested Coordinate class allows for the creation of Coordinate objects in the
    * FlagellaWidthProfile_ class. These coordinates are made of X Y coordinates on an image, but
    * they also contain information, including the gray value of the pixel at that location and the
    * slope of the line on which the coordinate is defined.
    * 
    * @author Matthew Reynolds
    *
    */
   class Coordinate {
      
      private double xVal;
      private double yVal;
      private double slope;
      private int pixelValue;
      
      /**
       * Method that allows for the setting of the X value of this Coordinate. Typically, the X
       * value is set when the Coordinate object is made and then it is not changed.
       * 
       * @param x
       */
      public void setXValue(double x) {
         xVal = x;
      }
      
      /**
       * Method that allows for the setting of the Y value of this Coordinate. Typically, the Y
       * value is set when the Coordinate object is made and then it is not changed.
       * 
       * @param y
       */
      public void setYValue(double y) {
         yVal = y;
      }
      
      /**
       * Method that allows for the setting of the slope of the line on which this Coordinate is
       * defined.<br>
       * Typically, the pixel value is set when the Coordinate object is made and then it is not
       * changed.
       * 
       * @param slope
       */
      public void setSlope(double slope) {
         this.slope = slope;
      }
      
      /**
       * Method that allows for the setting of the pixel value of this Coordinate. Typically, the
       * pixel value is set when the Coordinate object is made and then it is not changed.
       * 
       * @param ip
       */
      public void setPixelValue(ImageProcessor ip) {
         pixelValue = ip.getPixel((int) xVal, (int) yVal);
      }
      
      /**
       * Method that returns the X value of this Coordinate
       */
      public double getXValue() {
         return xVal;
      }
      
      /**
       * Method that returns the Y value of this Coordinate
       */
      public double getYValue() {
         return yVal;
      }
      
      /**
       * Method that returns the slope of the line on which this Coordinate is defined
       */
      public double getSlope() {
         return slope;
      }
      
      /**
       * Method that returns the gray value of the pixel at this Coordinate
       */
      public int getPixelValue() {
         return pixelValue;
      }
   }
}