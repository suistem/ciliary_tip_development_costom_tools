package Cilia;

import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import ij.IJ;
import ij.ImagePlus;
import ij.plugin.filter.ExtendedPlugInFilter;
import ij.plugin.filter.PlugInFilterRunner;
import ij.process.ImageProcessor;

/**
 * This class automates the processing of images of cilia by functioning
 * more-or-less like a macro. The program first requires user input to
 * specify the location of image files to be processed. Then the program
 * requires the user to specify the location of the new files. Then, the
 * parameters for a median filter and bandpass filter are requested. The
 * program also inverts the contrast for all of the images so that the edge
 * contrast appears as a local maximum, to match the FlagellaWidthProfile
 * algorithm.
 * 
 * @author Matthew Reynolds
 */
public class CiliaImagePreProcessor_ implements ExtendedPlugInFilter {
   ImagePlus imp;
   String max = null;
   String min = null;
   String originalFileLocation = null;
   String newFileLocation = null;
   Double radius = null;
   
   @Override
   public void run(ImageProcessor ip) {
      if (max != null && min != null && originalFileLocation != null
            && newFileLocation != null && radius != null) {
         File[] files = new File(originalFileLocation).listFiles();
         for (File file : files) {
            BPFilterer(file);
         }
      }
   }
   
   /**
    * This method performs the median filter, BPF, and inversion operations
    * on the image passed to it.
    * 
    * @param file
    */
   public void BPFilterer(File file) {
      imp = IJ.openImage(file.getAbsolutePath());
      IJ.run(imp, "Median...", "Radius=" + radius);
      IJ.run(imp, "Bandpass Filter...", "filter_large=" + max + " filter_small="
            + min + " suppress=None tolerance=5 autoscale saturate");
      IJ.run(imp, "Invert", "");
      IJ.saveAs(imp, "Tiff",
            (newFileLocation + "\\" + file.getName() + "_postBPF"));
      imp.close();
   }
   
   @Override
   /**
    * This method requests user input for the median filter and the BPF. It
    * also requires the user to specify where the files are located and
    * where the new ones will be stored.
    */
   public int showDialog(ImagePlus imp, String command,
         PlugInFilterRunner pfr) {
      String Title = "BPF Parameter input";
      radius = Double.parseDouble(JOptionPane.showInputDialog(null,
            "What will your Median filter radius be?", Title, 1));
      max = JOptionPane.showInputDialog(null,
            "Filter large structures down to how many pixels?", Title, 1);
      min = JOptionPane.showInputDialog(null,
            "Filter small structures up to how many pixels?", Title, 1);
      JFileChooser chooser = new JFileChooser();
      chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
      chooser.setDialogTitle(
            "Please select the folder in which the original image files are stored");
      @SuppressWarnings("unused")
      int returnVal = chooser.showOpenDialog(null);
      originalFileLocation = chooser.getSelectedFile().getAbsolutePath();
      chooser.setDialogTitle(
            "Please select the folder in which the new images will be stored");
      returnVal = chooser.showOpenDialog(null);
      newFileLocation = chooser.getSelectedFile().getAbsolutePath();
      return 0;
   }
   
   @Override
   public int setup(String arg, ImagePlus imp) {
      return NO_IMAGE_REQUIRED;
   }
   
   @Override
   public void setNPasses(int nPasses) {
   }
   
}
